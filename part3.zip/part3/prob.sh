echo "Enter Filename with phrase (without extension):"
read PHRASE
echo "Enter Filename (without extension): "
read FILENAME

tr ' ' '\012' <$PHRASE.txt> $PHRASE.un
awk '{if(NR>1) print ant " " $1; ant=$1}' $PHRASE.un > $PHRASE.bi

tr ' ' '\012' <$FILENAME.txt> $FILENAME.un
awk '{if(NR>1) print ant " " $1; ant=$1}' $FILENAME.un > $FILENAME.bi

result=$((100))
i=$((0))
while read line
do
	i=$((i+1))
	unig=$(sed "${i}q;d" $PHRASE.un)
	unioc=$(grep -c $unig $FILENAME.un)
	bioc=$(grep -c "$line" $FILENAME.bi)	
	echo $result:$bioc:$unioc >count.txt
	result=$(awk  -F: '{printf $1*$2/$3}' count.txt)
done <$PHRASE.bi
echo $result% with $FILENAME.txt>prob.txt
