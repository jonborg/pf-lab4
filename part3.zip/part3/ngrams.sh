echo "Enter Filename (without extension);"
read FILENAME

tr ' ' '\012' <$FILENAME.txt> $FILENAME.pal | sort $FILENAME.pal | uniq -c | sort -n -r>$FILENAME.1
awk '{if(NR>1) print ant " " $1;ant=$1}' $FILENAME.pal | sort |uniq -c | grep -v '</s> <s>'|sort -n -r >$FILENAME.2
wc $FILENAME.1

head -10 $FILENAME.1 $FILENAME.2>spont_ngrams.txt
